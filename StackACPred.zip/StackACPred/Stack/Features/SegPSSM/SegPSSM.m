
clc;
close all;
clear all;

for t=1:10
    t
    PR=csvread(['pssm' num2str(t),'.csv']);
    P=PR(:,1:20);
    [L,a]=size(P);
    fL=round(L/2);  
    
    
    PY=P(fL+1:L,:);
   [MX,NX]=max(PX,[],2);
   [MY,NY]=max(PY,[],2);
   for i=1:20
       mx=0;
       for j=1:fL
            if NX(j,1)==i
              mx=mx+1;
            else
              mx=mx+0;
            end
       end
      Sg1(t,i)=mx/fL;
   end
   
     for i=1:20
       my=0;
       for j=1:(L-fL)
            if NY(j,1)==i
              my=my+1;
            else
              my=my+0;
            end
       end
      Sg2(t,i)=my/(L-fL);
     end
    
end


Sg2_CS_PSSM_ACP740= [Sg1 Sg2];
save Sg2_CS_PSSM_ACP740.mat;

%clearvars -except SDNA_CSAAC SDNA_CSCV



