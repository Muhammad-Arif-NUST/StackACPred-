% Side-Chain Mass Values of 20 Amino Acid

%EIIP VALUES OF AMINO ACIDS 
A=15;
C=47;
D=59;
E=73;
F=91;
G=1;
H=82;
I=57;
K=73;
L=57;
M=75;
N=58;
P=42;
Q=72;
R=101;
S=31;
T=45;
V=43;
W=130;
Y=107;




