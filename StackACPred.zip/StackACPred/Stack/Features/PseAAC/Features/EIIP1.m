% Hydrophobicity Values of 20 Amino Acid

%EIIP VALUES OF AMINO ACIDS 
A=0.62;
C=0.29;
D=-0.90;
E=-0.74;
F=1.19;
G=0.48;
H=-0.40;
I=1.38;
K=-1.50;
L=1.06;
M=064;
N=-0.78;
P=0.12;
Q=-0.85;
R=-2.53;
S=-0.18;
T=-0.05;
V=1.08;
W=0.81;
Y=0.26;




