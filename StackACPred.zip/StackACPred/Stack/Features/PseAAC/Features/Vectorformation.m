function [PpseAA]=Vectorformation(x,tiers)

 Frequency=AminoAcidFrequency(x);

% lemda=HPHO_HPHL_lemda(x,tiers);
%Also check whether the training and test data is loaded again
lemda=Amino_Acid_13_PhysChem_Prop(x,tiers);
% PpseAA=[lemda];
 PpseAA=[Frequency lemda];
% sum1=sum(PpseAA(1,1:20))+ sum(PpseAA(1,21:end));
% 
% Pu=PpseAA/sum1;
%&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
% save PpseAAnb PpseAA lemda;
return