function [lemda]=Amino_Acid_13_PhysChem_Prop(x,tiers)

% VEC1=HydrophobicityParser(x);
% VEC2=HydrophilicityParser(x);
% VEC3=MH_Parser(x);

%VEC1=CPV_Parser(x);
VEC1=EIIP_Parser1(x);
VEC2=EIIP_Parser2(x);
% VEC3=EIIP_Parser3(x);
% VEC4=EIIP_Parser4(x);
% VEC5=EIIP_Parser5(x);
% VEC6=EIIP_Parser6(x);
% VEC7=EIIP_Parser7(x);
% VEC8=EIIP_Parser8(x);
% VEC9=EIIP_Parser9(x);
% VEC10=EIIP_Parser10(x);
VEC11=EIIP_Parser11(x);
VEC12=EIIP_Parser12(x);
VEC13=EIIP_Parser13(x);

L=size(VEC1,2);
T1=[];
for i=1:tiers

 H1=[];
 H2=[];
%  H3=[];
%  H4=[];
%  H5=[];
%  H6=[];
%  H7=[];
%  H8=[];
%  H9=[];
%  H10=[];
 H11=[];
 H12=[];
 H13=[];
    for j=1:L-i
 
        H1=[H1  ( VEC1(j)* VEC1(j+i) ) ];
        H2=[H2  ( VEC2(j)* VEC2(j+i) ) ];
%         H3=[H3  ( VEC3(j)* VEC3(j+i) ) ];
%         H4=[H4  ( VEC4(j)* VEC4(j+i) ) ];
%         H5=[H5  ( VEC5(j)* VEC5(j+i) ) ];
%         H6=[H6  ( VEC6(j)* VEC6(j+i) ) ];
%         H7=[H7  ( VEC7(j)* VEC7(j+i) ) ];
%         H8=[H8  ( VEC8(j)* VEC8(j+i) ) ];
%         H9=[H9  ( VEC9(j)* VEC9(j+i) ) ];
%        H10=[H10 ( VEC10(j)* VEC10(j+i) ) ];
       H11=[H11 ( VEC11(j)* VEC11(j+i) ) ];
       H12=[H12 ( VEC12(j)* VEC12(j+i) ) ];
       H13=[H13 ( VEC13(j)* VEC13(j+i) ) ];
    end

T1=[ T1 (sum(H1)/(L-i)) (sum(H2)/(L-i)) (sum(H11)/(L-i)) (sum(H12)/(L-i)) (sum(H13)/(L-i))];
    
end
w=0.5;
lemda= 0.5*T1;
% lemda= (100*.5)*T1;
return