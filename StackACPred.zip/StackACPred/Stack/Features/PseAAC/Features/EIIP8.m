% D (Aspartic acid) 0.1263
% R (Arginine) 0.0959
% F (Phenylalanine) 0.0946
% T (Threonine) 0.0941
% C (Cysteine) 0.0829
% S (Serine) 0.0829
% M (Methionine) 0.0823
% Q (Glutamine) 0.0761
% W (Tryptophan) 0.0548
% Y (Tyrosine) 0.0516
% A (Alanine) 0.0373
% K (Lysine) 0.0371
% H (Histidine) 0.0242
% P (Proline) 0.0198
% E (Glutamic acid) 0.0058
% V (Valine) 0.0057
% G (Glycine) 0.0050
% N (Asparagine) 0.0036
% I (Isoleucine) 0.0000
% L (Leucine) 0.0000

%EIIP VALUES OF AMINO ACIDS 
A=89.09;
C=121.2;
D=133.1;
E=147.1;
F=165.2;
G=75.07;
H=155.2;
I=131.2;
K=146.2;
L=131.2;
M=149.2;
N=132.1;
P=115.1;
Q=146.2;
R=174.2;
S=105.1;
T=119.1;
V=117.2;
W=204.2;
Y=181.2;




