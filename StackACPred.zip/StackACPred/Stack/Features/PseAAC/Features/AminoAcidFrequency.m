function [Frequency]=AminoAcidFrequency(x)

index=find('A'==x);
a = size(index,2);
Frequency=[];
Frequency=[Frequency a/size(x,2)];

index=find('C'==x);
a = size(index,2);
Frequency=[Frequency a/size(x,2)];

index=find('D'==x);
a = size(index,2);
Frequency=[Frequency a/size(x,2)];

index=find('E'==x);
a = size(index,2);
Frequency=[Frequency a/size(x,2)];

index=find('F'==x);
a = size(index,2);
Frequency=[Frequency a/size(x,2)];

index=find('G'==x);
a = size(index,2);
Frequency=[Frequency a/size(x,2)];

index=find('H'==x);
a = size(index,2);
Frequency=[Frequency a/size(x,2)];

index=find('I'==x);
a = size(index,2);
Frequency=[Frequency a/size(x,2)];

index=find('K'==x);
a = size(index,2);
Frequency=[Frequency a/size(x,2)];

index=find('L'==x);
a = size(index,2);
Frequency=[Frequency a/size(x,2)];

index=find('M'==x);
a = size(index,2);
Frequency=[Frequency a/size(x,2)];

index=find('N'==x);
a = size(index,2);
Frequency=[Frequency a/size(x,2)];

index=find('P'==x);
a = size(index,2);
Frequency=[Frequency a/size(x,2)];

index=find('Q'==x);
a = size(index,2);
Frequency=[Frequency a/size(x,2)];

index=find('R'==x);
a = size(index,2);
Frequency=[Frequency a/size(x,2)];

index=find('S'==x);
a = size(index,2);
Frequency=[Frequency a/size(x,2)];

index=find('T'==x);
a = size(index,2);
Frequency=[Frequency a/size(x,2)];

index=find('V'==x);
a = size(index,2);
Frequency=[Frequency a/size(x,2)];

index=find('W'==x);
a = size(index,2);
Frequency=[Frequency a/size(x,2)];

index=find('Y'==x);
a = size(index,2);
Frequency=100 *[Frequency a/size(x,2)];

return