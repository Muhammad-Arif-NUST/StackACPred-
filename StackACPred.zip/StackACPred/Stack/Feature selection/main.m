

%path('E:/SVM-RFE-CBR-v1.3',path);
%path('E:\libsvm-3.20\matlab',path);



%##########Labeling############

load Physicochemical_740;
load PSSM_ACP740_Feature40;
load Sg3_CS_PSSM_ACP740;

% 
X=[featurs];

data=X;
nn=size(data,1);
label=linspace(1,nn,nn);
label=label';

for i=1:740
    if(i<=376)
    label(i) = 1;
    else 
    label(i) = 0;
    end
end

train_matrix=data;
train_labels=label;

%##############################


[Train_matrix,PS] = mapminmax(X');
train_data = Train_matrix';


param.kerType = 2;
param.rfeC = 16;
param.rfeG = 0.0078;
param.useCBR = true;
param.Rth = 0.9;
%[bestacc,best_dim,ftRank,ftScore]=optem_Dim(train_data,label,param);
aftRank=ftRank';

%mappedX=ft_select(train_data, ftRank,best_dim);

% [bestacc,bestc,bestg]=SVMcg(label,mappedX,-5,5,-5,5,5,1,1,1,2 )
cg_str='-c 16 -g 0.0078 -b 1';
[Predict_label,Scores] = JackknifeValidation(mappedX,label,cg_str);

label_mappedX=[label,mappedX];

save ACP740_optemDim label_mappedX


 
 
 


